import pathlib, subprocess, os, json, hashlib, shutil

root = pathlib.Path(__file__).resolve().parent
toolchain = root / 'audit3-toolchain'
repo = root / 'audit-3e924e6-gcc13'
cwd = repo / 'uai32'
compiler = toolchain / 'extracted/usr/bin/x86_64-linux-gnu-gcc-13'
for name, target in [('ld', 'x86_64-linux-gnu-ld.bfd'), ('as', 'x86_64-linux-gnu-as')]:
    link = toolchain / 'binutils/usr/bin' / name
    if not link.exists():
        link.symlink_to(target)
for name, target in [('lib', 'usr/lib'), ('lib64', 'usr/lib64')]:
    link = toolchain / 'sysroot' / name
    if not link.exists():
        link.symlink_to(target)
shutil.copy2('/usr/lib/x86_64-linux-gnu/libgcc_s.so.1', toolchain / 'sysroot/usr/lib/x86_64-linux-gnu/libgcc_s.so.1')
cc = f'{compiler} --sysroot={toolchain}/sysroot -B{toolchain}/binutils/usr/bin/ -idirafter /usr/include -idirafter /usr/include/x86_64-linux-gnu'
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = str(toolchain / 'binutils/usr/lib/x86_64-linux-gnu')
env['PYTHONPATH'] = str(root / 'linux-deps')
before = subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
p = subprocess.run(['make', '-B', 'CC=' + cc], cwd=cwd, env=env, text=True, capture_output=True)
(root / 'audit3-pinned-build.log').write_text(p.stdout + p.stderr)
print(p.stdout, p.stderr)
assert p.returncode == 0, p.returncode
committed = subprocess.check_output(['git', 'show', 'HEAD:uai32/dist/uai32'], cwd=repo)
built = (cwd / 'uai32').read_bytes()
record = {'compiler': cc, 'pre_build_status': before, 'returncode': p.returncode,
          'built_bytes': len(built), 'built_sha256': hashlib.sha256(built).hexdigest(),
          'committed_bytes': len(committed), 'committed_sha256': hashlib.sha256(committed).hexdigest(),
          'byte_identical_to_committed': built == committed}
(root / 'audit3-pinned-results.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
