import pathlib, urllib.request, subprocess, json, hashlib

root = pathlib.Path(__file__).resolve().parent / 'audit3-toolchain'
groups = {
    'binutils': ('b/binutils', [
        'binutils-x86-64-linux-gnu_2.42-4ubuntu2_amd64.deb',
        'libbinutils_2.42-4ubuntu2_amd64.deb',
        'libctf0_2.42-4ubuntu2_amd64.deb',
        'libctf-nobfd0_2.42-4ubuntu2_amd64.deb',
        'libsframe1_2.42-4ubuntu2_amd64.deb',
    ]),
    'sysroot': ('g/glibc', [
        'libc6-dev_2.39-0ubuntu8_amd64.deb',
        'libc6_2.39-0ubuntu8_amd64.deb',
    ]),
}
records = []
for target, (area, names) in groups.items():
    dest = root / target
    dest.mkdir(exist_ok=True)
    for name in names:
        url = 'https://archive.ubuntu.com/ubuntu/pool/main/' + area + '/' + name
        path = root / name
        if not path.exists():
            urllib.request.urlretrieve(url, path)
        subprocess.run(['dpkg-deb', '-x', str(path), str(dest)], check=True)
        records.append({'url': url, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'bytes': path.stat().st_size})
(root / 'linker-libc-package-records.json').write_text(json.dumps(records, indent=2) + '\n')
print('Extracted linker and libc into isolated scratch directories; no system packages installed.')
