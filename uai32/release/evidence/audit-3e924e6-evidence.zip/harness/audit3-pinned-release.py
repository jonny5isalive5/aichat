import pathlib, subprocess, os, json, hashlib

root = pathlib.Path(__file__).resolve().parent
repo = root / 'audit-3e924e6-gcc13'
cwd = repo / 'uai32'
tc = root / 'audit3-toolchain'
build = json.loads((root / 'audit3-pinned-results.json').read_text())
env = os.environ.copy()
env['LD_LIBRARY_PATH'] = str(tc / 'binutils/usr/lib/x86_64-linux-gnu')
env['PYTHONPATH'] = str(root / 'linux-deps')
cc = build['compiler']
for label, args in [
    ('data', ['python3', 'get_mnist.py']),
    ('dist', ['make', 'CC=' + cc, 'dist']),
    ('verify', ['make', 'CC=' + cc, 'verify']),
]:
    p = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True)
    (root / f'audit3-pinned-{label}.log').write_text(p.stdout + p.stderr)
    print(label, p.returncode, p.stdout[-1200:], p.stderr[-500:], flush=True)
    assert p.returncode == 0, (label, p.returncode)

artifacts = {}
for name in ['uai32', 'iris.model', 'mnist14.model', 'rings.model', 'spirals.model', 'SHA256SUMS']:
    data = (cwd / 'dist' / name).read_bytes()
    committed = subprocess.check_output(['git', 'show', 'HEAD:uai32/dist/' + name], cwd=repo)
    artifacts[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                       'byte_identical_to_committed': data == committed}
    assert data == committed, name
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
record = {'head': head, 'all_artifacts_byte_identical_to_committed': True,
          'post_release_git_status': status, 'artifacts': artifacts}
(root / 'audit3-pinned-release-results.json').write_text(json.dumps(record, indent=2) + '\n')
assert status == '', status
print(json.dumps(record, indent=2), flush=True)
