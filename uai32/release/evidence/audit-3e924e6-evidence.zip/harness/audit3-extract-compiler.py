import pathlib,urllib.request,subprocess,json,hashlib
root=pathlib.Path(__file__).resolve().parent/'audit3-toolchain'; root.mkdir(exist_ok=True); install=root/'extracted'; install.mkdir(exist_ok=True)
base='https://archive.ubuntu.com/ubuntu/pool/main/g/gcc-13/'
names=['gcc-13-x86-64-linux-gnu_13.3.0-6ubuntu2~24.04.1_amd64.deb',
       'cpp-13-x86-64-linux-gnu_13.3.0-6ubuntu2~24.04.1_amd64.deb',
       'libgcc-13-dev_13.3.0-6ubuntu2~24.04.1_amd64.deb']
records=[]
for name in names:
    path=root/name
    if not path.exists(): urllib.request.urlretrieve(base+name,path)
    subprocess.run(['dpkg-deb','-x',str(path),str(install)],check=True)
    records.append({'url':base+name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size})
(root/'package-records.json').write_text(json.dumps(records,indent=2)+'\n')
compiler=install/'usr/bin/x86_64-linux-gnu-gcc-13'
p=subprocess.run([str(compiler),'--version'],capture_output=True,text=True);print(p.stdout,p.stderr)
p=subprocess.run([str(compiler),'-print-search-dirs'],capture_output=True,text=True);print(p.stdout,p.stderr)
