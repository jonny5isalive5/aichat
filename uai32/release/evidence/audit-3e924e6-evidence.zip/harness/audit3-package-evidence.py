import pathlib, subprocess, hashlib, json, zipfile

base = pathlib.Path(__file__).resolve().parent.parent
work = base / 'work'
out = base / 'outputs'
out.mkdir(exist_ok=True)
repo = work / 'audit-3e924e6'
sha = '3e924e600ef6b65eff9f00668cb283b259930049'
focused = json.loads((repo / 'uai32/work/focused-audit-results.json').read_text())
regressions = json.loads((repo / 'uai32/work/regression-results.json').read_text())
pinned = json.loads((work / 'audit3-pinned-release-results.json').read_text())
assert pinned['head'] == sha and pinned['post_release_git_status'] == ''
tracked = subprocess.check_output(['git', 'ls-files', 'uai32'], cwd=repo, text=True).splitlines()
source_records = {}
for name in tracked:
    if name.startswith('uai32/dist/'):
        continue
    original = subprocess.check_output(['git', 'show', sha + ':' + name], cwd=repo)
    actual = (repo / name).read_bytes()
    assert actual == original, name
    source_records[name] = {'sha256': hashlib.sha256(actual).hexdigest(), 'unchanged': True}
native_dist_equal = all((repo / 'uai32/dist' / name).read_bytes() ==
                       (work / 'audit-3e924e6-repro/uai32/dist' / name).read_bytes()
                       for name in pinned['artifacts'])
assert native_dist_equal
summary = {
    'verdict': 'PASS', 'repository': 'jonny5isalive5/aichat', 'pull_request': 2,
    'commit': sha, 'scope': 'Two remaining P2 findings from c2c1497 and existing release gates',
    'audit_boundary': {'detached_checkouts': True, 'source_files_unchanged': True,
                       'remote_mutations': False, 'branch_commits_or_pushes': False},
    'previous_findings': {
        'normalization_range_overflow': {'status': 'FIXED', 'independent_probes': {
            key: focused[key] for key in focused if key.startswith('range_')}},
        'failed_dist_publication': {'status': 'FIXED', 'failure_injection': focused['final_publication_mv_failure'],
                                    'normal_control': focused['normal_publication_after_fault']},
    },
    'release_gates': {
        'verification': 'ALL CHECKS PASSED (28/28)',
        'regression_groups': 18, 'recorded_subprocess_invocations': len(regressions),
        'sanitizer_invocations': sum(any('sanitize' in str(a) for a in r.get('args', [])) for r in regressions),
        'sanitizers': ['AddressSanitizer', 'UndefinedBehaviorSanitizer', 'float-cast-overflow'],
        'committed_checksums': 'All five artifacts passed SHA-256 verification before regeneration',
        'mnist_correct': 9781, 'mnist_total': 10000, 'mnist_accuracy_percent': 97.81, 'mnist_loss': 0.0766,
        'committed_executable_bytes': 9188, 'mnist_model_bytes': 21468, 'combined_bytes': 30656,
        'byte_limit': 32768, 'spare_bytes': 2112,
        'pinned_clean_tree_reproduction': pinned,
        'two_independent_native_builds_byte_identical': native_dist_equal,
        'native_toolchain': 'gcc 15.2 / binutils 2.46 / glibc 2.43; 9140-byte executable',
        'pinned_toolchain': 'gcc 13.3 / binutils 2.42 / glibc 2.39 headers and startup objects; 9188-byte executable',
    },
    'new_material_defects': [], 'source_integrity': source_records,
    'evidence_notes': [
        'Publication fault probe used real make dist training/evaluation, not a fake training process.',
        'The final stage-to-dist mv alone failed; restoration mv was independently recorded.',
        'Full sanitizer regression suite ran on GCC 15.2; overflow controls also exercised the committed 9188-byte executable.',
        'Pinned executable, all four retrained models and SHA256SUMS reproduced committed bytes exactly; final checkout remained clean.',
    ],
}
result_file = out / 'audit-3e924e6-results.json'
result_file.write_text(json.dumps(summary, indent=2) + '\n')
evidence_file = out / 'audit-3e924e6-evidence.zip'
with zipfile.ZipFile(evidence_file, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(result_file, 'audit-summary.json')
    for p in sorted(work.glob('audit3-*.log')):
        z.write(p, 'logs/' + p.name)
    for name in ['audit3-pinned-results.json', 'audit3-pinned-release-results.json',
                 'audit3-focused-probes.py', 'audit3-pinned-build.py', 'audit3-pinned-release.py',
                 'audit3-extract-compiler.py', 'audit3-extract-linker-libc.py', 'audit3-package-evidence.py']:
        z.write(work / name, 'harness/' + name)
    for name in ['package-records.json', 'linker-libc-package-records.json']:
        z.write(work / 'audit3-toolchain' / name, 'toolchain/' + name)
    z.write(repo / 'uai32/work/focused-audit-results.json', 'results/focused-audit-results.json')
    z.write(repo / 'uai32/work/regression-results.json', 'results/regression-results.json')
    for name in ['uai32.c', 'Makefile', 'measure.sh', 'verify.sh', 'check_artifacts.py', 'refcheck.py',
                 'get_mnist.py', 'regression_tests.py', 'README.md']:
        z.writestr('commit-source/' + name, subprocess.check_output(['git', 'show', sha + ':uai32/' + name], cwd=repo))
    for name in pinned['artifacts']:
        z.writestr('committed-dist/' + name, subprocess.check_output(['git', 'show', sha + ':uai32/dist/' + name], cwd=repo))
digest = hashlib.sha256(evidence_file.read_bytes()).hexdigest()
(out / 'audit-3e924e6-evidence.sha256').write_text(digest + '  ' + evidence_file.name + '\n')
print(json.dumps({'verdict': summary['verdict'], 'unchanged_source_files': len(source_records),
                  'regression_invocations': len(regressions), 'evidence_bytes': evidence_file.stat().st_size,
                  'evidence_sha256': digest}, indent=2))
