import pathlib, subprocess, os, tempfile, shutil, struct, math, json, hashlib, shlex
ROOT=pathlib.Path(__file__).resolve().parent/'audit-3e924e6/uai32'
RESULT={}; ENV={**os.environ,'ASAN_OPTIONS':'detect_leaks=0','UBSAN_OPTIONS':'halt_on_error=1'}
def run(key,args,cwd=ROOT,extra=None):
    p=subprocess.run(list(map(str,args)),cwd=cwd,env={**ENV,**(extra or {})},capture_output=True,text=True,timeout=120)
    RESULT[key]={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    assert 'AddressSanitizer:' not in p.stderr and 'runtime error:' not in p.stderr, p.stderr
    return p
def snapshot(directory):
    return {str(p.relative_to(directory)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
            for p in sorted(directory.rglob('*')) if p.is_file()}
with tempfile.TemporaryDirectory(prefix='focused-audit-',dir=ROOT/'work') as d:
    scratch=pathlib.Path(d); sanitized=scratch/'sanitized'
    original=subprocess.run(['git','show','HEAD:uai32/dist/uai32'],cwd=ROOT,capture_output=True,check=True).stdout
    committed=scratch/'committed-uai32'; committed.write_bytes(original); committed.chmod(0o755)
    assert len(original)==9188 and hashlib.sha256(original).hexdigest()=='996d73cba9676e8932206b9c80493becde6d04b6a57b70839999b0824c0186cb'
    p=run('sanitizer_build',['cc','-std=c99','-O1','-g','-ffp-contract=off','-fsanitize=address,undefined,float-cast-overflow',
                           '-fno-sanitize-recover=all',ROOT/'uai32.c','-lm','-o',sanitized]); assert p.returncode==0
    for name,exe in [('normal',ROOT/'uai32'),('sanitizer',sanitized),('committed',committed)]:
        for magnitude,reject in [('3e38',True),('1.7e38',False)]:
            key='range_'+name+'_'+magnitude; data=scratch/(key+'.txt'); data.write_text(f'{magnitude} 0\n-{magnitude} 1\n')
            model=scratch/(key+'.model'); assert not model.exists()
            p=run(key,[exe,'train',data,model,'2','1','0.05','1'])
            RESULT[key]['model_exists']=model.exists()
            if reject:
                assert p.returncode>0 and not model.exists() and 'feature range overflows' in p.stderr, RESULT[key]
            else:
                assert p.returncode==0 and model.is_file(), RESULT[key]
                b=model.read_bytes(); mean,scale=struct.unpack('<2f',b[8:16]); assert math.isfinite(mean) and math.isfinite(scale) and scale>0
                RESULT[key]['mean']=mean; RESULT[key]['scale']=scale; RESULT[key]['model_bytes']=len(b)
    p=scratch/'publication-copy'; p.mkdir()
    for name in ['Makefile','measure.sh','check_artifacts.py','uai32.c','uai32']: shutil.copy2(ROOT/name,p/name)
    shutil.copytree(ROOT/'dist',p/'dist'); (p/'data').symlink_to(ROOT/'data',target_is_directory=True)
    before=snapshot(p/'dist'); tools=p/'tools'; tools.mkdir(); real_mv=shutil.which('mv'); assert real_mv
    moves=p/'moves.log'; marker=p/'final-move-failed'
    wrapper=('#!/bin/sh\n'
             f'printf "%s -> %s\\n" "$1" "$2" >> {shlex.quote(str(moves))}\n'
             'case "$1" in work/stage.*)\n'
             f'  : > {shlex.quote(str(marker))}\n'
             '  echo "audit: injected failure at final publication mv" >&2; exit 1;;\nesac\n'
             f'exec {shlex.quote(real_mv)} "$@"\n')
    (tools/'mv').write_text(wrapper); (tools/'mv').chmod(0o755)
    r=run('final_publication_mv_failure',['make','dist'],cwd=p,extra={'PATH':str(tools)+os.pathsep+ENV['PATH']})
    assert r.returncode>0 and marker.exists() and (p/'dist').is_dir()
    after=snapshot(p/'dist'); leftovers=[str(f.relative_to(p)) for pattern in ['stage.*','previous-dist.*','dist.*'] for f in (p/'work').glob(pattern)]
    assert before==after and not leftovers
    RESULT['final_publication_mv_failure'].update({'previous_dist_byte_identical':True,'before':before,'after':after,
                                                  'leftover_stage_or_backup_paths':leftovers,'mv_calls':moves.read_text().splitlines()})
    r=run('normal_publication_after_fault',['make','dist'],cwd=p)
    assert r.returncode==0 and snapshot(p/'dist')==before
    leftovers=[str(f.relative_to(p)) for pattern in ['stage.*','previous-dist.*','dist.*'] for f in (p/'work').glob(pattern)]
    assert not leftovers
    RESULT['normal_publication_after_fault'].update({'published_dist_matches_validated_artifacts':True,'leftover_stage_or_backup_paths':leftovers})
(ROOT/'work/focused-audit-results.json').write_text(json.dumps(RESULT,indent=2)+'\n')
for key,value in RESULT.items():
    print(key, {k:v for k,v in value.items() if k not in ['stdout','stderr','before','after']})
